package com.example.math.models

class Questions : ArrayList<QuestionsItem>()