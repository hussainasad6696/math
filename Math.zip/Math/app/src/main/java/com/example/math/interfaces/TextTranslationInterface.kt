package com.example.math.interfaces

interface TextTranslationInterface {
    fun onSuccessTextRecognitionListener(text: String)
    fun onFilerTextRecognitionListener(text: String)
}