package com.example.math.models

enum class QuestionTypes {
    ADDITION,
    SUBTRACTION,
    DIVISION,
    MULTIPLICATION,
    MIX,
    LCM,
    HCF,
    QUADRATIC
}