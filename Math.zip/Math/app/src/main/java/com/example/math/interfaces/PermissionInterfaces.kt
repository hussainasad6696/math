package com.example.math.interfaces

interface PermissionInterfaces {
    fun permissionGrantedListener()
    fun permissionDeniedListener()
}